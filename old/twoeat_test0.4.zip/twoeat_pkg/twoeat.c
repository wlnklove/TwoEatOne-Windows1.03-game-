/* ====================================================================
 * twoeatone.c - 主程序文件
 * 包含 WinMain、主窗口过程、初始化函数
 * 使用 K&R C 语法，适配 MSC 4.0 + Windows 1.03 SDK
 * ==================================================================== */

#include "twoeat.h"
#include <string.h>

/* --------------------------------------------------------------------
 * 全局变量定义
 * -------------------------------------------------------------------- */

HANDLE hInst;                    /* 应用程序实例句柄 */
HWND hWndMain = NULL;            /* 主窗口句柄 */
HWND hModelessDlg = NULL;        /* 当前无模式对话框 */
GameState gameState;             /* 游戏状态 */
BoardLayout boardLayout;         /* 棋盘布局 */
HistoryEntry history[MAX_HISTORY]; /* 悔棋历史 */
int historyCount = 0;            /* 历史记录数 */
int historyCurrent = 0;          /* 当前历史指针 */
HBRUSH hbrBackground = NULL;     /* 背景画刷 */
HCURSOR hCursorArrow = NULL;     /* 标准箭头光标 */
char szAppName[] = "TwoEatOne";  /* 窗口类名 */

/* --------------------------------------------------------------------
 * WinMain - 程序入口点
 * 
 * Windows 程序的入口点，相当于 DOS 程序的 main()。
 * 负责注册窗口类、创建主窗口、运行消息循环。
 * 
 * 参数：
 *   hInstance     - 当前实例句柄
 *   hPrevInstance - 前一个实例句柄（Windows 1.03 中可能为 NULL）
 *   lpCmdLine     - 命令行参数
 *   nCmdShow      - 窗口初始显示方式
 * 
 * 返回值：消息循环的退出码
 * -------------------------------------------------------------------- */
int PASCAL WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
HANDLE hInstance;
HANDLE hPrevInstance;
LPSTR lpCmdLine;
int nCmdShow;
{
    MSG msg;

    /* 注册窗口类（仅在第一个实例时注册） */
    if (!InitApplication(hInstance))
        return FALSE;

    /* 初始化实例，创建主窗口 */
    if (!InitInstance(hInstance, nCmdShow))
        return FALSE;

    /* 检测存档目录，尝试载入最新存档；若无存档则开始新游戏 */
    EnsureSaveDir();
    if (!LoadLatestSave()) {
        StartNewGame(MODE_NORMAL);
    }

    /* StartNewGame 在 UpdateWindow 之后才执行，棋盘数据已就位但屏幕画的还是空棋盘
     * 必须手动触发一次重绘，否则看不到棋子 */
    InvalidateRect(hWndMain, NULL, TRUE);

    /* ----------------------------------------------------------------
     * 消息循环
     *
     * Windows 1.03 的消息循环。GetMessage 从队列取消息；
     * 如果有无模式对话框打开，用 IsDialogMessage 让它处理对话框消息
     * （如 Tab 键切换焦点等），否则正常翻译和分发消息。
     * ---------------------------------------------------------------- */
    while (GetMessage(&msg, NULL, 0, 0)) {
        if (hModelessDlg != NULL && IsDialogMessage(hModelessDlg, &msg))
            continue;
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return msg.wParam;
}

/* --------------------------------------------------------------------
 * InitApplication - 注册窗口类
 * 
 * 在 Windows 1.03 中，窗口类需要在第一个实例时注册。
 * 后续实例共享已注册的类。
 * 
 * WNDCLASS 结构各字段说明：
 *   style        - 窗口类风格，CS_HREDRAW|CS_VREDRAW 表示窗口大小
 *                  变化时重绘整个客户区（棋盘需要随窗口缩放）
 *   lpfnWndProc  - 指向窗口过程函数的指针
 *   hInstance    - 所属实例
 *   hCursor      - 默认光标（箭头）
 *   hbrBackground - 背景画刷（NULL 表示自行处理 WM_ERASEBKGND）
 *   lpszMenuName - 菜单资源名
 *   lpszClassName- 窗口类名
 * -------------------------------------------------------------------- */
BOOL InitApplication(hInstance)
HANDLE hInstance;
{
    WNDCLASS wc;

    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = MainWndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = NULL;             /* Windows 1.03 对自定义图标支持有限 */
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = NULL;      /* 自行处理背景擦除 */
    wc.lpszMenuName = "MainMenu"; /* 对应 .rc 中的菜单资源名 */
    wc.lpszClassName = szAppName;

    return RegisterClass(&wc);
}

/* --------------------------------------------------------------------
 * InitInstance - 创建主窗口
 * 
 * 创建并显示主窗口。
 * 
 * CreateWindow 参数说明：
 *   lpszClassName - 已注册的窗口类名
 *   lpszWindowName- 窗口标题栏文字
 *   dwStyle       - 窗口风格
 *                   WS_TILEDWINDOW 包含标题栏、系统菜单、
 *                   最大化/最小化按钮、可调边框
 *   x, y          - 窗口初始位置（0,0）
 *   nWidth, nHeight- 窗口初始尺寸
 *   hwndParent    - 父窗口（无）
 *   hmenu         - 菜单（NULL 表示使用类菜单）
 *   hInstance     - 实例句柄
 *   lpvParam      - 额外参数（无）
 * -------------------------------------------------------------------- */
BOOL InitInstance(hInstance, nCmdShow)
HANDLE hInstance;
int nCmdShow;
{
    RECT rc;

    hInst = hInstance;

    /* 创建主窗口 */
    hWndMain = CreateWindow(
        szAppName,
        "Two Eat One",           /* 窗口标题 */
        WS_TILEDWINDOW,
        0, 0,
        480, 520,                /* 初始窗口大小 */
        NULL, NULL, hInstance, NULL);

    if (hWndMain == NULL)
        return FALSE;

    /* 创建 EGA 绿色背景画刷 */
    hbrBackground = CreateSolidBrush(RGB(0, 128, 0));

    /* 显示并更新窗口 */
    ShowWindow(hWndMain, nCmdShow);
    UpdateWindow(hWndMain);

    return TRUE;
}

/* --------------------------------------------------------------------
 * MainWndProc - 主窗口过程
 * 
 * 处理所有发送给主窗口的消息。这是 Windows 程序的核心。
 * 每个消息通过 switch-case 分支处理。
 * 
 * 参数：
 *   hWnd    - 窗口句柄
 *   message - 消息类型
 *   wParam  - 消息参数1（16位）
 *   lParam  - 消息参数2（32位）
 * -------------------------------------------------------------------- */
LONG FAR PASCAL MainWndProc(hWnd, message, wParam, lParam)
HWND hWnd;
unsigned message;
WORD wParam;
LONG lParam;
{
    HDC hdc;
    PAINTSTRUCT ps;
    RECT rc;

    switch (message) {

    /* ----------------------------------------------------------------
     * WM_CREATE - 窗口创建时
     * 
     * 在系统菜单中添加分隔符和"关于"选项。
     * GetSystemMenu 获取系统菜单句柄，ChangeMenu 追加菜单项。
     * Win 1.03 没有 AppendMenu，用 ChangeMenu + MF_APPEND 代替。
     * MF_SEPARATOR 表示分隔线，MF_STRING 表示文字菜单项。
     * ---------------------------------------------------------------- */
    case WM_CREATE:
    {
        HMENU hSysMenu;
        HMENU hMainMenu;

        hSysMenu = GetSystemMenu(hWnd, FALSE);
        ChangeMenu(hSysMenu, 0, NULL, 0, MF_APPEND | MF_SEPARATOR);
        ChangeMenu(hSysMenu, 0, "About", IDM_SYSABOUT, MF_APPEND | MF_STRING);

        /* 初始化对弈模式菜单对勾：默认 AI 对弈 */
        hMainMenu = GetMenu(hWnd);
        CheckMenuItem(hMainMenu, IDM_AI_MODE, MF_CHECKED);
        CheckMenuItem(hMainMenu, IDM_TWO_PLAYER, MF_UNCHECKED);

        return 0L;
    }

    /* ----------------------------------------------------------------
     * WM_SIZE - 窗口大小变化时
     * 
     * 重新计算棋盘布局，使棋盘居中且随窗口缩放。
     * wParam = 尺寸变化类型
     * lParam = 新的客户区尺寸（LOWORD=宽, HIWORD=高）
     * ---------------------------------------------------------------- */
    case WM_SIZE:
    {
        CalcBoardLayout(LOWORD(lParam), HIWORD(lParam));
        InvalidateRect(hWnd, NULL, FALSE);
        return 0L;
    }

    /* ----------------------------------------------------------------
     * WM_ERASEBKGND - 擦除背景
     * 
     * 自行处理背景填充，使用绿色画刷。
     * 返回 1 表示已处理，避免系统默认擦除引起闪烁。
     * ---------------------------------------------------------------- */
    case WM_ERASEBKGND:
    {
        HDC hDC = (HDC)wParam;
        GetClientRect(hWnd, &rc);
        FillRect(hDC, &rc, hbrBackground);
        return 1L;
    }

    /* ----------------------------------------------------------------
     * WM_PAINT - 绘制客户区
     * 
     * 使用双缓冲技术：先在内存 DC 中画好所有内容，
     * 再用 BitBlt 一次性拷贝到屏幕，避免闪烁。
     * 
     * CreateCompatibleDC   - 创建与屏幕兼容的内存 DC
     * CreateCompatibleBitmap - 创建兼容位图
     * SelectObject         - 将位图选入 DC
     * BitBlt               - 位块传输（从内存到屏幕）
     * ---------------------------------------------------------------- */
    case WM_PAINT:
    {
        HDC hMemDC;
        HBITMAP hBitmap, hOldBitmap;

        hdc = BeginPaint(hWnd, &ps);
        GetClientRect(hWnd, &rc);

        /* 始终重新计算棋盘布局
         * 不能只在 cellSize==0 时才算——切换游戏模式后，
         * 旧布局的 cellSize 非零但参数不匹配新模式，导致网格和棋子错位 */
        CalcBoardLayout(rc.right, rc.bottom);

        /* 创建内存 DC 实现双缓冲
         * 最大化时窗口很大，CreateCompatibleBitmap 可能因内存不足失败
         * 失败时回退到直接绘制屏幕（无闪烁保护但至少能画出来） */
        hMemDC = CreateCompatibleDC(hdc);
        hBitmap = CreateCompatibleBitmap(hdc, rc.right, rc.bottom);

        if (hMemDC != NULL && hBitmap != NULL) {
            hOldBitmap = SelectObject(hMemDC, hBitmap);
            DrawEntireBoard(hMemDC, &rc);
            BitBlt(hdc, 0, 0, rc.right, rc.bottom, hMemDC, 0, 0, SRCCOPY);
            SelectObject(hMemDC, hOldBitmap);
            DeleteObject(hBitmap);
        } else {
            /* 位图分配失败（窗口太大），直接画到屏幕 */
            if (hBitmap != NULL)
                DeleteObject(hBitmap);
            DrawEntireBoard(hdc, &rc);
        }
        if (hMemDC != NULL)
            DeleteDC(hMemDC);

        EndPaint(hWnd, &ps);
        return 0L;
    }

    /* ----------------------------------------------------------------
     * WM_LBUTTONDOWN - 鼠标左键按下
     * 
     * 处理棋子选择和走棋。
     * wParam = 按键状态标志
     * lParam = 鼠标坐标（LOWORD=X, HIWORD=Y）
     * ---------------------------------------------------------------- */
    case WM_LBUTTONDOWN:
    {
        int mouseX, mouseY;
        int row, col;

        /* 游戏结束时忽略点击 */
        if (gameState.gameOver)
            break;

        /* AI 模式下，只有玩家回合（白棋）可以操作
         * 双人模式下，双方都可以操作 */
        if (!gameState.twoPlayer && gameState.currentPlayer != WHITE)
            break;

        mouseX = LOWORD(lParam);
        mouseY = HIWORD(lParam);

        /* 检测点击位置对应的棋盘格 */
        if (!BoardHitTest(mouseX, mouseY, &row, &col))
            break;

        if (gameState.selRow < 0) {
            /* ---- 未选中棋子状态：尝试选中 ---- */
            if (gameState.board[row][col] == gameState.currentPlayer) {
                /* 选中当前走棋方的棋子 */
                gameState.selRow = row;
                gameState.selCol = col;
                InvalidateRect(hWnd, NULL, FALSE);
            } else {
                /* 点击了空位或对方棋子，蜂鸣提示 */
                MessageBeep(0);
            }
        } else {
            /* ---- 已选中棋子状态：尝试走棋 ---- */
            if (row == gameState.selRow && col == gameState.selCol) {
                /* 点击同一棋子：取消选中 */
                gameState.selRow = -1;
                gameState.selCol = -1;
                InvalidateRect(hWnd, NULL, FALSE);
            } else if (gameState.board[row][col] == gameState.currentPlayer) {
                /* 点击另一颗己方棋子：切换选中 */
                gameState.selRow = row;
                gameState.selCol = col;
                InvalidateRect(hWnd, NULL, FALSE);
            } else if (gameState.board[row][col] == EMPTY) {
                /* 点击空位：尝试走棋 */
                if (IsValidMove(gameState.selRow, gameState.selCol, row, col)) {
                    /* 执行走棋 */
                    MakeMove(gameState.selRow, gameState.selCol, row, col);
                    gameState.selRow = -1;
                    gameState.selCol = -1;
                    InvalidateRect(hWnd, NULL, FALSE);

                    /* 检查游戏是否结束 */
                    if (gameState.gameOver) {
                        EndGame(gameState.gameOver);
                    } else if (gameState.currentPlayer == BLACK && !gameState.twoPlayer) {
                        /* 轮到 AI，设置延时定时器（仅 AI 模式） */
                        SetTimer(hWnd, IDT_AI_MOVE, 500, NULL);
                    }
                } else {
                    /* 不是有效走法，蜂鸣提示 */
                    MessageBeep(0);
                }
            } else {
                /* 点击对方棋子：蜂鸣提示 */
                MessageBeep(0);
            }
        }
        return 0L;
    }

    /* ----------------------------------------------------------------
     * WM_TIMER - 定时器触发
     * 
     * 用于 AI 延时走棋。走完后销毁定时器。
     * ---------------------------------------------------------------- */
    case WM_TIMER:
    {
        if (wParam == IDT_AI_MOVE) {
            KillTimer(hWnd, IDT_AI_MOVE);
            /* 仅 AI 模式下且轮到黑棋时执行 AI 走棋 */
            if (!gameState.gameOver && gameState.currentPlayer == BLACK && !gameState.twoPlayer) {
                DoAIMove();
                InvalidateRect(hWnd, NULL, FALSE);
                if (gameState.gameOver) {
                    EndGame(gameState.gameOver);
                }
            }
        }
        return 0L;
    }

    /* ----------------------------------------------------------------
     * WM_COMMAND - 菜单命令
     * 
     * wParam = 菜单项 ID
     * ---------------------------------------------------------------- */
    case WM_COMMAND:
    {
        switch (wParam) {

        case IDM_NEWGAME:
            /* 开始新游戏（普通模式） */
            StartNewGame(MODE_NORMAL);
            InvalidateRect(hWnd, NULL, TRUE);
            break;

        case IDM_CHALLENGE:
            /* 开始挑战模式（4x4 格子） */
            StartNewGame(MODE_CHALLENGE);
            InvalidateRect(hWnd, NULL, TRUE);
            break;

        case IDM_AI_MODE:
            /* 切换到 AI 对弈模式 */
            gameState.twoPlayer = 0;
            CheckMenuItem(GetMenu(hWnd), IDM_AI_MODE, MF_CHECKED);
            CheckMenuItem(GetMenu(hWnd), IDM_TWO_PLAYER, MF_UNCHECKED);
            /* 清除选中状态（可能选中了黑棋） */
            gameState.selRow = -1;
            gameState.selCol = -1;
            InvalidateRect(hWnd, NULL, FALSE);
            /* 如果当前轮到黑棋，启动 AI */
            if (gameState.currentPlayer == BLACK && !gameState.gameOver) {
                SetTimer(hWnd, IDT_AI_MOVE, 500, NULL);
            }
            break;

        case IDM_TWO_PLAYER:
            /* 切换到双人对弈模式 */
            gameState.twoPlayer = 1;
            CheckMenuItem(GetMenu(hWnd), IDM_AI_MODE, MF_UNCHECKED);
            CheckMenuItem(GetMenu(hWnd), IDM_TWO_PLAYER, MF_CHECKED);
            /* 取消可能正在等待的 AI 定时器 */
            KillTimer(hWnd, IDT_AI_MOVE);
            /* 清除选中状态 */
            gameState.selRow = -1;
            gameState.selCol = -1;
            InvalidateRect(hWnd, NULL, FALSE);
            break;

        case IDM_UNDO:
            /* 悔棋 */
            if (UndoMove()) {
                InvalidateRect(hWnd, NULL, FALSE);
            } else {
                MessageBeep(0);
            }
            break;

        case IDM_SAVE:
            /* 打开存档对话框（无模式） */
            if (hModelessDlg != NULL)
                BringWindowToTop(hModelessDlg);
            else {
                hModelessDlg = CreateDialog(hInst, "SaveDlg", hWnd, SaveDlgProc);
                /* CreateDialog 不会自动显示窗口，必须手动 ShowWindow */
                if (hModelessDlg != NULL) {
                    ShowWindow(hModelessDlg, 1);
                    BringWindowToTop(hModelessDlg);
                }
            }
            break;

        case IDM_LOAD:
            /* 打开载入对话框（无模式） */
            if (hModelessDlg != NULL)
                BringWindowToTop(hModelessDlg);
            else {
                hModelessDlg = CreateDialog(hInst, "LoadDlg", hWnd, LoadDlgProc);
                if (hModelessDlg != NULL) {
                    ShowWindow(hModelessDlg, 1);
                    BringWindowToTop(hModelessDlg);
                }
            }
            break;

        case IDM_SETTINGS:
            /* 打开设置对话框（无模式） */
            if (hModelessDlg != NULL)
                BringWindowToTop(hModelessDlg);
            else {
                hModelessDlg = CreateDialog(hInst, "SettingsDlg", hWnd, SettingsDlgProc);
                if (hModelessDlg != NULL) {
                    ShowWindow(hModelessDlg, 1);
                    BringWindowToTop(hModelessDlg);
                }
            }
            break;

        case IDM_HELP:
            /* 打开帮助对话框（模态） */
            DialogBox(hInst, "HelpDlg", hWnd, HelpDlgProc);
            break;

        case IDM_ABOUT:
            /* 打开关于对话框（模态） */
            DialogBox(hInst, "AboutDlg", hWnd, AboutDlgProc);
            break;
        }
        return 0L;
    }

    /* ----------------------------------------------------------------
     * WM_SYSCOMMAND - 系统菜单命令
     * 
     * 检查是否点击了系统菜单中的"关于"项。
     * ---------------------------------------------------------------- */
    case WM_SYSCOMMAND:
    {
        if (wParam == IDM_SYSABOUT) {
            DialogBox(hInst, "AboutDlg", hWnd, AboutDlgProc);
            return 0L;
        }
        break;
    }

    /* ----------------------------------------------------------------
     * WM_DESTROY - 窗口销毁
     * 
     * 清理资源，退出消息循环。
     * PostQuitMessage 发送 WM_QUIT 消息，使 GetMessage 返回 FALSE。
     * ---------------------------------------------------------------- */
    case WM_DESTROY:
    {
        if (hbrBackground != NULL)
            DeleteObject(hbrBackground);
        PostQuitMessage(0);
        return 0L;
    }

    default:
        break;
    }

    /* 未处理的消息交给默认窗口过程 */
    return DefWindowProc(hWnd, message, wParam, lParam);
}

/* --------------------------------------------------------------------
 * StartNewGame - 开始新游戏
 * 
 * 重置棋盘到初始状态，根据先手设置决定谁先走棋。
 * 
 * 普通模式：4x4 交叉点，各 4 子在底线
 * 挑战模式：4x4 格子，各 4 子在底线行
 * 
 * 先后手规则（默认模式）：
 *   - 胜则交换先后手
 *   - 败则玩家先手
 *   - 可在设置中改为始终先手/后手
 * -------------------------------------------------------------------- */
void StartNewGame(mode)
int mode;
{
    int row, col;

    /* 重置游戏状态 */
    gameState.mode = mode;
    gameState.selRow = -1;
    gameState.selCol = -1;
    gameState.gameOver = 0;
    gameState.whiteCount = 4;
    gameState.blackCount = 4;
    gameState.lastMoveRow = -1;
    gameState.lastMoveCol = -1;

    /* 清空棋盘 */
    for (row = 0; row < BOARD_SIZE; row++) {
        for (col = 0; col < BOARD_SIZE; col++) {
            gameState.board[row][col] = EMPTY;
        }
    }

    /* 摆放初始棋子 */
    /* 第 0 行（顶部）放黑棋（AI） */
    for (col = 0; col < BOARD_SIZE; col++)
        gameState.board[0][col] = BLACK;

    /* 第 3 行（底部）放白棋（玩家） */
    for (col = 0; col < BOARD_SIZE; col++)
        gameState.board[3][col] = WHITE;

    /* 确定先手方 */
    if (gameState.firstSetting == FIRST_ALWAYS) {
        gameState.firstPlayer = WHITE;   /* 玩家先手 */
    } else if (gameState.firstSetting == SECOND_ALWAYS) {
        gameState.firstPlayer = BLACK;   /* AI 先手 */
    } else {
        /* FIRST_DEFAULT 模式：保持上次更新值
         * 但首次游戏时 firstPlayer 为 0（全局零初始化），需要默认为玩家先手 */
        if (gameState.firstPlayer != WHITE && gameState.firstPlayer != BLACK)
            gameState.firstPlayer = WHITE;
    }

    gameState.currentPlayer = gameState.firstPlayer;

    /* 清空悔棋历史并保存初始状态 */
    historyCount = 0;
    historyCurrent = 0;
    SaveHistoryEntry();

    /* 如果 AI 先手，设置定时器延时走棋 */
    if (gameState.currentPlayer == BLACK && !gameState.gameOver && !gameState.twoPlayer) {
        SetTimer(hWndMain, IDT_AI_MOVE, 500, NULL);
    }
}

/* --------------------------------------------------------------------
 * EndGame - 游戏结束处理
 * 
 * 显示胜负信息，并根据默认先后手规则更新下一局先手。
 * 
 * 默认规则：
 *   - 玩家胜 → 交换先后手（先→后，后→先）
 *   - 玩家败 → 玩家始终先手
 * -------------------------------------------------------------------- */
void EndGame(winner)
int winner;
{
    char msg[80];

    if (gameState.twoPlayer) {
        /* 双人模式：直接报告胜方 */
        if (winner == WHITE)
            strcpy(msg, "White wins! Press N for a new game.");
        else
            strcpy(msg, "Black wins! Press N for a new game.");
    } else {
        /* AI 模式：报告玩家胜负 */
        if (winner == WHITE) {
            strcpy(msg, "You win! Press N for a new game.");
        } else {
            strcpy(msg, "You lose! Press N for a new game.");
        }
    }

    /* 仅在默认模式下更新先后手 */
    if (gameState.firstSetting == FIRST_DEFAULT) {
        if (winner == WHITE) {
            /* 玩家胜：交换先后手 */
            if (gameState.firstPlayer == WHITE)
                gameState.firstPlayer = BLACK;
            else
                gameState.firstPlayer = WHITE;
        } else {
            /* 玩家败：玩家先手 */
            gameState.firstPlayer = WHITE;
        }
    }

    MessageBox(hWndMain, msg, "Game Over", MB_OK | MB_ICONASTERISK);
}
