@echo off
REM ============================================================
REM  build.bat - 走四子（二吃一）构建脚本
REM  适用于 DOS 3.33 / DOSBox + MSC 4.0 + Windows 1.03 SDK
REM ============================================================

REM === 设置路径（根据你的实际安装位置修改）===
set PATH=C:\MSC;C:\WINDEV;%PATH%
set INCLUDE=C:\MSC\include;C:\WINDEV\include
set LIB=C:\MSC\lib;C:\WINDEV\lib

echo Compiling...

REM === 编译所有 C 文件 ===
REM -AM  中型内存模型
REM -G2  80286 优化
REM -Gsw Windows 序言尾声 + 关闭栈探针（必须！）
REM -c   只编译不链接
REM -Zpe 打包结构
cl -AM -G2 -Gsw -c -Zpe twoeat.c
cl -AM -G2 -Gsw -c -Zpe board.c
cl -AM -G2 -Gsw -c -Zpe game.c
cl -AM -G2 -Gsw -c -Zpe ai.c
cl -AM -G2 -Gsw -c -Zpe dialogs.c
cl -AM -G2 -Gsw -c -Zpe save.c

if errorlevel 1 goto fail

echo Linking...

REM === 链接（LINK 4.x + 响应文件）===
link @twoeat.lnk

if errorlevel 1 goto fail

echo Compiling resources...

REM === 编译并嵌入资源 ===
rc twoeat.rc twoeat.exe

if errorlevel 1 goto fail

echo.
echo Build successful! twoeat.exe is ready.
goto end

:fail
echo.
echo Build FAILED! Check errors above.

:end
